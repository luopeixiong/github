# -*- coding: utf-8 -*-
import scrapy
from .CookiesGet import pedataCookieJar as pe
ymd = pe.ymd
from .Helper import pedataCookieJar as Co
from user_agent import generate_user_agent
import random
from Pedata.items import PedataItem
from .myselector import Selector as S

class PedataSpider(scrapy.Spider):
    name = "pedata"
    allowed_domains = ["pedata.cn"]
    start_urls = ['http://pe.pedata.cn/getListFund.action',
                  'http://pe.pedata.cn/getListNeeqList.action',
                  'http://pe.pedata.cn/getListIpo.action',
                  'http://pe.pedata.cn/getListExit.action',
                  'http://pe.pedata.cn/getListMa.action',
                  'http://pe.pedata.cn/getListInvest.action',
                  'http://pe.pedata.cn/getListOrg.action',
                  'http://pe.pedata.cn/getListEp.action']
    cookieNums = 230
    #请求JSESSIONID列表 尽可能减少cookiejar信息
    cookies = []
    custom_settings = {'DOWNLOADER_MIDDLEWARES': {
                        'Pedata.middlewares.RotateUserAgentMiddleware':401,
                        'Pedata.middlewares.ProxyMiddleware':700,
                        },
                        'DEPTH_PRIORITY' : 1,
                        'CONCURRENT_REQUESTS' :10,
                        'CONCURRENT_REQUESTS_PER_IP' :5,
                        'DOWNLOAD_DELAY':0.5
                        }
    print(cookies)
    def start_requests(self):
        self.cookies = [{'JSESSIONID':x['JSESSIONID']} for x in Co.main(self.cookieNums)]
        start_y = 2017
        end_y = 2018
        start_m = 1
        end_m = 13
        for url in self.start_urls:
#            if url == 'http://pe.pedata.cn/getListOrg.action':
#                """机构"""
#                for y in reversed(range(start_y,end_y)):
#                    for m in range(start_m,end_m):
#                        datedatas = ymd(y,m,2)
#                        for datedata in datedatas:
#                            start = datedata[0]
#                            end = datedata[1]
#                            page = 1
#                            resultNums = None
#                            data = Co.request_from_my_url(start,end,page,resultNums=resultNums)
#                            cookies  = random.choice(self.cookies)
#                            yield scrapy.FormRequest('http://pe.pedata.cn/getListOrg.action',
#                                                      cookies=cookies,
#                                                      headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
#                                                      formdata=data,
#                                                      meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
#                                                      priority = 50,
#                                                      callback = self.orgListParse
#                                                      )
#            if url == 'http://pe.pedata.cn/getListInvest.action':
#                """投资事件"""
#                for y in reversed(range(start_y,end_y)):
#                    for m in range(start_m,end_m):
#                        datedatas = ymd(y,m,2)
#                        for datedata in datedatas:
#                            start = datedata[0]
#                            end = datedata[1]
#                            page = 1
#                            resultNums = None
#                            data = Co.request_from_my_url1(start,end,page,resultNums=resultNums)
#                            cookies  = random.choice(self.cookies)
#                            yield scrapy.FormRequest('http://pe.pedata.cn/getListInvest.action',
#                                                      cookies=cookies,
#                                                      headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
#                                                      formdata=data,
#                                                      meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
#                                                      priority = 50,
#                                                      callback = self.InvestListParse
#                                                      )
#            if url == 'http://pe.pedata.cn/getListMa.action':
#                """并购事件"""
#                for y in reversed(range(start_y,end_y)):
#                    for m in range(start_m,end_m):
#                        datedatas = ymd(y,m,2)
#                        for datedata in datedatas:
#                            start = datedata[0]
#                            end = datedata[1]
#                            page = 1
#                            resultNums = None
#                            data = Co.request_from_my_url2(start,end,page,resultNums=resultNums)
#                            cookies  = random.choice(self.cookies)
#                            print(data)
#                            yield scrapy.FormRequest('http://pe.pedata.cn/getListMa.action',
#                                                      cookies=cookies,
#                                                      headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
#                                                      formdata=data,
#                                                      meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
#                                                      priority = 50,
#                                                      callback = self.MaListParse
#                                                      )
#            if url == 'http://pe.pedata.cn/getListExit.action':
#                '''退出事件'''
#                for y in reversed(range(start_y,end_y)):
#                    for m in range(start_m,end_m):
#                        datedatas = ymd(y,m,2)
#                        for datedata in datedatas:
#                            start = datedata[0]
#                            end = datedata[1]
#                            page = 1
#                            resultNums = None
#                            data = Co.request_from_my_url3(start,end,page,resultNums=resultNums)
#                            cookies  = random.choice(self.cookies)
#                            yield scrapy.FormRequest('http://pe.pedata.cn/getListExit.action',
#                                                      cookies=cookies,
#                                                      headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
#                                                      formdata=data,
#                                                      meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
#                                                      priority = 50,
#                                                      callback = self.ExitListParse
#                                                      )
#            if url == 'http://pe.pedata.cn/getListNeeqList.action':
#                '''新三板挂牌事件'''
#                for y in reversed(range(start_y,end_y)):
#                    for m in range(start_m,end_m):
#                        datedatas = ymd(y,m,2)
#                        for datedata in datedatas:
#                            start = datedata[0]
#                            end = datedata[1]
#                            page = 1
#                            resultNums = None
#                            data = Co.request_from_my_url4(start,end,page,resultNums=resultNums)
#                            cookies  = random.choice(self.cookies)
#                            yield scrapy.FormRequest('http://pe.pedata.cn/getListNeeqList.action',
#                                                      cookies=cookies,
#                                                      headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
#                                                      formdata=data,
#                                                      meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
#                                                      priority = 50,
#                                                      callback = self.NeeqListParse
#                                                      )
#            if url == 'http://pe.pedata.cn/getListFund.action':
#                pass
#                '''私募股权'''
#                for y in reversed(range(start_y,end_y)):
#                    for m in range(start_m,end_m):
#                        datedatas = ymd(y,m,2)
#                        for datedata in datedatas:
#                            start = datedata[0]
#                            end = datedata[1]
#                            page = 1
#                            resultNums = None
#                            data = Co.request_from_my_url5(start,end,page,resultNums=resultNums)
#                            cookies  = random.choice(self.cookies)
#                            yield scrapy.FormRequest('http://pe.pedata.cn/getListFund.action',
#                                                      cookies=cookies,
#                                                      headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
#                                                      formdata=data,
#                                                      meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
#                                                      priority = 50,
#                                                      callback = self.FundListParse
#                                                      )
#            if url == 'http://pe.pedata.cn/getListIpo.action':
#                '''上市事件'''
#                for y in reversed(range(start_y,end_y)):
#                    for m in range(start_m,end_m):
#                        datedatas = ymd(y,m,2)
#                        for datedata in datedatas:
#                            start = datedata[0]
#                            end = datedata[1]
#                            page = 1
#                            resultNums = None
#                            data = Co.request_from_my_url6(start,end,page,resultNums=resultNums)
#                            cookies  = random.choice(self.cookies)
#                            yield scrapy.FormRequest('http://pe.pedata.cn/getListIpo.action',
#                                                      cookies=cookies,
#                                                      headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
#                                                      formdata=data,
#                                                      meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
#                                                      priority = 50,
#                                                      callback = self.IpoListParse
#                                                      )
            if url == 'http://pe.pedata.cn/getListEp.action':
                '''企业列表'''
                for y in reversed(range(1949,end_y)):
                    for m in range(start_m,end_m):
                        datedatas = ymd(y,m,2)
                        for datedata in datedatas:
                            start = datedata[0]
                            end = datedata[1]
                            page = 1
                            resultNums = None
                            data = Co.request_from_my_url7(start,end,page,resultNums=resultNums)
                            cookies  = random.choice(self.cookies)
                            yield scrapy.FormRequest('http://pe.pedata.cn/getListEp.action',
                                                      cookies=cookies,
                                                      headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                                      formdata=data,
                                                      meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                                      priority = 50,
                                                      callback = self.EpListParse
                                                      )
    def orgListParse(self, response):
        item = PedataItem()
        result = {}
        page = response.meta['page']
        start = response.meta['start']
        end = response.meta['end']
        result['start']=start
        result['endtime']=end
        result['page'] = page
        
        resultNums = response.meta['resultNums']
        
        if response.status ==200 and response.meta['resultNums'] is not None:
            resultNums = response.meta['resultNums']
        elif response.status == 200:
            resultNums = response.xpath("//div[@class='search_result']/div[1]/p[1]/span[1]/text()").extract_first()
            if resultNums is not None:
                resultNums = int(resultNums)
            else:
                data =  Co.request_from_my_url(start,end,page)
                cookies  = random.choice(self.cookies)
                return scrapy.FormRequest('http://pe.pedata.cn/getListOrg.action',
                                         cookies=cookies,
                                         headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                         formdata=data,
                                         meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                         priority = 4,
                                         callback = self.orgListParse,
                                         dont_filter = True,
                                         )
        else:
            # print(response.text)
            data =  Co.request_from_my_url(start,end,page)
            cookies  = random.choice(self.cookies)
            return scrapy.FormRequest('http://pe.pedata.cn/getListOrg.action',
                                     cookies=cookies,
                                     headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                     formdata=data,
                                     meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                     priority = 3,
                                     callback = self.orgListParse,
                                     dont_filter = True,
                                     )
        # print(start, end, page, resultNums)
        # print(response.text)
        org_ids = response.xpath("//a[contains(@href,'getDetailOrg.action?param.org_id=')]/@href").extract()
        if org_ids:
            for org_id in org_ids:
                result['org_id'] = org_id.split("=")[-1]
                result['total'] = resultNums
                item['result'] = result
#                yield item
                org_id = result['org_id']
                
                if org_id.isdigit():
                    url = 'http://pe.pedata.cn/getDetailOrg.action?param.org_id={org_id}'.format(org_id=org_id)
                    cookies = random.choice(self.cookies)
                    yield scrapy.Request(url,
                                         headers = {'User-Agent':generate_user_agent(os=('mac', 'win'))},
                                         cookies=cookies,
                                         callback = self.org_parse
                                         )
        if page < resultNums/25:
            page+=1
            cookies  = random.choice(self.cookies)
            data = Co.request_from_my_url(start,end,page,resultNums=resultNums)
            yield scrapy.FormRequest('http://pe.pedata.cn/getListOrg.action',
                                      cookies=cookies,
                                      headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                      formdata=data,
                                      meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                      priority = 2,
                                      callback = self.orgListParse
                                      )
    def org_parse(self, response):
        item = PedataItem()
#        print(response.text)
        result = {}
        result['org_id'] = response.url.split("=")[-1]
        if "Login timeout" in response.text or "setTimeout" in response.text:
            cookies = random.choice(self.cookies)
            return scrapy.Request(response.url,
                                 method = "GET",
                                 cookies = cookies,
                                 headers = {"User-Agent":generate_user_agent(os=('mac', 'win'))},
                                 priority = 1,
                                 dont_filter = True,
                                 callback = self.org_parse)
        if response.status != 200:
            cookies = random.choice(self.cookies)
            return scrapy.Request(response.url,
                                 method = "GET",
                                 cookies = cookies,
                                 headers = {"User-Agent":generate_user_agent(os=('mac', 'win'))},
                                 priority = 1,
                                 dont_filter = True,
                                 callback = self.org_parse)
        configs = [{'n':"中文简称","En":"org_name","v":"//div[contains(text(),'中文简称：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"官网","En":"org_website","v":"//label[@id='freeHidden']/a/@href","t":"xpath_join","dt":""},
                   {'n':"英文简称","En":"Ename","v":"//div[contains(text(),'英文简称：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"中文曾用名","En":"Name_used_before","v":"//div[contains(text(),'中文曾用名：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"成立时间","En":"set_up_time","v":"//div[contains(text(),'成立时间：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"资本类型","En":"capital_type","v":"//div[contains(text(),'资本类型：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"组织形式","En":"org_form","v":"//div[contains(text(),'组织形式：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"VC/PE","En":"VC_PE","v":"//div[contains(text(),'VC/PE：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"管理资本量","En":"manager_capital","v":"//div[contains(text(),'管理资本量：')]/following-sibling::div[1]/text()","t":"xpath_first","dt":""},
                   {'n':"注册地区","En":"Registered_area","v":"//div[contains(text(),'注册地区：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"工商注册号","En":"Business_registration_number","v":"//div[contains(text(),'工商注册号：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"国有背景详情","En":"state_background","v":"//div[contains(text(),'国有背景详情：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"公司总部","En":"headquarters","v":"//div[contains(text(),'公司总部：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"是否备案","En":"is_record","v":"//div[contains(text(),'是否备案：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"中国-地址","En":"China_address","v":"//div[contains(text(),'中国 总部')]/following-sibling::div[1]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"中国-邮编","En":"China_Postal_Code","v":"//div[contains(text(),'中国 总部')]/following-sibling::div[2]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"中国-联系人","En":"China_Contacts","v":"//div[contains(text(),'中国 总部')]/following-sibling::div[3]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"中国-联系电话","En":"China_Contact_number","v":"//div[contains(text(),'中国 总部')]/parent::div/following-sibling::div[1]/div[2]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"中国-传真","En":"China_fax","v":"//div[contains(text(),'中国 总部')]/parent::div/following-sibling::div[1]/div[3]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"中国-邮箱","En":"China_email","v":"//div[contains(text(),'中国 总部')]/parent::div/following-sibling::div[1]/div[4]/div[2]/a/text()","t":"xpath_join","dt":""},
                   {'n':"亚洲-地址","En":"Asia_address","v":"//div[contains(text(),'亚洲 总部')]/following-sibling::div[1]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"亚洲-邮编","En":"Asia_Postal_Code","v":"//div[contains(text(),'亚洲 总部')]/following-sibling::div[2]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"亚洲-联系人","En":"Asia_Contacts","v":"//div[contains(text(),'亚洲 总部')]/following-sibling::div[3]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"亚洲-联系电话","En":"Asia_Contact_number","v":"//div[contains(text(),'亚洲 总部')]/parent::div/following-sibling::div[1]/div[2]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"亚洲-传真","En":"Asia_fax","v":"//div[contains(text(),'亚洲 总部')]/parent::div/following-sibling::div[1]/div[3]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"亚洲-邮箱","En":"Asia_email","v":"//div[contains(text(),'亚洲 总部')]/parent::div/following-sibling::div[1]/div[4]/div[2]/a/text()","t":"xpath_join","dt":""},
                   {'n':"全球-地址","En":"Global_address","v":"//div[contains(text(),'全球 总部')]/following-sibling::div[1]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"全球-邮编","En":"Global_Postal_Code","v":"//div[contains(text(),'全球 总部')]/following-sibling::div[2]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"全球-联系人","En":"Global_Contacts","v":"//div[contains(text(),'全球 总部')]/following-sibling::div[3]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"全球-联系电话","En":"Global_Contact_number","v":"//div[contains(text(),'全球 总部')]/parent::div/following-sibling::div[1]/div[2]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"全球-传真","En":"Global_fax","v":"//div[contains(text(),'全球 总部')]/parent::div/following-sibling::div[1]/div[3]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"全球-邮箱","En":"Global_email","v":"//div[contains(text(),'全球 总部')]/parent::div/following-sibling::div[1]/div[4]/div[2]/a/text()","t":"xpath_join","dt":""},
                   {'n':"描述","En":"describe","v":"//div[contains(text(),'描述')]/following-sibling::div[1]/form/div//text()","t":"xpath_join","dt":""},
                   {'n':"拟投资阶段","En":"investment_stage","v":"//div[contains(text(),'拟投资阶段：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"拟投行业(清科)","En":"investment_industry","v":"//div[contains(text(),'拟投行业(清科)：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"拟投地区","En":"investment_area","v":"//div[contains(text(),'拟投地区：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   #{'n':"","En":"","v":"//div[contains(text(),'管理资本量：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"投资大陆资本量","En":"investment_in_China","v":"//div[contains(text(),'投资大陆资本量：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"单项最大投资额","En":"Maximum_single_investment","v":"//div[contains(text(),'单项最大投资额：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"单项最小投资额","En":"Minimum_single_investment","v":"//div[contains(text(),'单项最小投资额：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"投资标准","En":"Investment_standard","v":"//div[contains(text(),'投资标准：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"增值服务","En":"Value_added_service","v":"//div[contains(text(),'增值服务：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""}
                   ]
        html = S.replace_invalid_html_char(response.text)
        res = scrapy.Selector(text = html)
        result = dict()
        for config in configs:
            result[config['En']] = S.select_content(res, config)
            if result[config['En']]:
                result[config['En']] = S.replace_all(result[config['En']])
        result['org_id'] = response.url.split('=')[-1]
        item['result'] = result
        item['db'] = 'dbo.Pedata_Org'
        item['keys'] = ['org_name']
        
        if result['org_name']:
            yield item
    def InvestListParse(self, response):
        item = PedataItem()
        result = {}
        page = response.meta['page']
        start = response.meta['start']
        end = response.meta['end']
        result['start']=start
        result['endtime']=end
        result['page'] = page
        resultNums = response.meta['resultNums']
        if response.status ==200 and response.meta['resultNums'] is not None:
            resultNums = response.meta['resultNums']
        elif response.status ==200:
            resultNums = response.xpath("//div[@class='search_result']/div[1]/p[1]/span[1]/text()").extract_first()
            if resultNums is not None:
                resultNums = int(resultNums)
            else:
                cookies = random.choice(self.cookies)
                data =  Co.request_from_my_url1(start,end,page)
                return scrapy.FormRequest('http://pe.pedata.cn/getListInvest.action',
                                         cookies=cookies,
                                         headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                         formdata=data,
                                         meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                         priority = 5,
                                         callback = self.InvestListParse,
                                         dont_filter = True
                                         )
        else:
            # print(response.text)
            data =  Co.request_from_my_url1(start,end,page)
            cookies = random.choice(self.cookies)
            return scrapy.FormRequest('http://pe.pedata.cn/getListInvest.action',
                                     cookies=cookies,
                                     headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                     formdata=data,
                                     meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                     priority = 5,
                                     callback = self.InvestListParse,
                                     dont_filter = True
                                     )
        print(start, end, page, resultNums)
#        print(response.text)
        tree1 = response.xpath("//div[@class='leftTableDivID float_left search_width20']/table/tr")
        tree2 = response.xpath("//div[@class='leftTableDivID float_right search_width20']/table/tr")
        tree3 = response.xpath("//div[@id='rightBodyDivID']/div/table/tr")
        configs1 = [{'n':"机构名称",'En':"org_name","t":"xpath_join","v":"td[1]/a/text()","d":""},
                    {'n':"机构ID",'En':"org_id","t":"xpath_join","v":"td[1]/a/@href","d":""},
                    {'n':"公司名称",'En':"ep_name","t":"xpath_join","v":"td[2]/a/text()","d":""},
                    {'n':"公司ID",'En':"ep_id","t":"xpath_join","v":"td[2]/a/@href","d":""}
                    ]
        configs2 = [{'n':"投资事件ID",'En':"Investment_Event_ID","t":"xpath_join","v":"td[1]/a/@href","d":""}
                    ]
        configs3 = [{'n':"基金名称",'En':"fund_name","t":"xpath_join","v":"td[3]/a/text()","d":""},
                    {'n':"基金ID",'En':"fund_ID","t":"xpath_join","v":"td[3]/a/@href","d":""},
                    {'n':"企业标签",'En':"Enterprise_label","t":"xpath_join","v":"td[4]/text()","d":""},
                    {'n':"行业(清科)",'En':"Profession_QK","t":"xpath_join","v":"td[5]/text()","d":""},
                    {'n':"地区",'En':"area","t":"xpath_join","v":"td[6]/text()","d":""},
                    {'n':"投资类型",'En':"Investment_type","t":"xpath_join","v":"td[7]/text()","d":""},
                    {'n':"投资阶段",'En':"Investment_stage","t":"xpath_join","v":"td[8]/text()","d":""},
                    {'n':"投资时间",'En':"Investment_date","t":"xpath_join","v":"td[9]/text()","d":""},
                    {'n':"投资金额(M)",'En':"Investment_money_M","t":"xpath_join","v":"td[10]/text()","d":""},
                    {'n':"投资金额(USD/M)",'En':"Investment_money_USDM","t":"xpath_join","v":"td[11]/text()","d":""},
                    {'n':"股权",'En':"stock_right","t":"xpath_join","v":"td[12]/text()","d":""},
                    {'n':"轮次",'En':"turn","t":"xpath_join","v":"td[13]/text()","d":""},
                    {'n':"投资人",'En':"Investor","t":"xpath_join","v":"td[14]/text()","d":""},
                    {'n':"企业估值(USD/M)",'En':"Business_valuation","t":"xpath_join","v":"td[15]/text()","d":""},
                    {'n':"P/E",'En':"P_E","t":"xpath_join","v":"td[16]/text()","d":""},
                    {'n':"行业(国标)",'En':"Industry_GB","t":"xpath_join","v":"td[17]/text()","d":""},
                    {'n':"行业(证监会)",'En':"Industry_SFC","t":"xpath_join","v":"td[18]/text()","d":""},
                    {'n':"上市交易所",'En':"Listed_exchange","t":"xpath_join","v":"td[19]/text()","d":""},
                    
                    ]
#        configs = configs1+configs2+configs3
        for x,y,z in zip(tree1,tree2,tree3):
            result = {}
            for config in configs1:
                result[config['En']] = S.select_content(x, config)
                if result[config['En']]:
                    result[config['En']] = S.replace_all(result[config['En']])
            for config in configs2:
                result[config['En']] = S.select_content(y, config)
                if result[config['En']]:
                    result[config['En']] = S.replace_all(result[config['En']])
            for config in configs3:
                result[config['En']] = S.select_content(z, config)
                if result[config['En']]:
                    result[config['En']] = S.replace_all(result[config['En']])
            result['ep_id'] = result['ep_id'].split('=')[-1] if hasattr(result['ep_id'],'split') else None    
            result['Investment_Event_ID'] = result['Investment_Event_ID'].split('=')[-1] if hasattr(result['Investment_Event_ID'],'split') else None    
            result['org_id'] = result['org_id'].split('=')[-1] if hasattr(result['org_id'],'split') else None    
            item['result']=result
            item['db'] = 'dbo.Pedata_InvestEvent'
            item['keys'] = ["Investment_Event_ID"]
            if result['org_id']:
                yield item 
                
            
        
        
        if page < resultNums/25:
            page+=1
            cookies = random.choice(self.cookies)
            data = Co.request_from_my_url1(start,end,page,resultNums=resultNums)
            yield scrapy.FormRequest('http://pe.pedata.cn/getListInvest.action',
                                      cookies=cookies,
                                      headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                      formdata=data,
                                      meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                      priority = 5,
                                      callback = self.InvestListParse
                                      )
    def MaListParse(self, response):
        item = PedataItem()
        result = {}
        page = response.meta['page']
        start = response.meta['start']
        end = response.meta['end']
        result['start']=start
        result['endtime']=end
        result['page'] = page
        resultNums = response.meta['resultNums']
        if response.status ==200 and response.meta['resultNums'] is not None:
            resultNums = response.meta['resultNums']
        elif response.status ==200:
            resultNums = response.xpath("//div[@class='search_result']/div[1]/p[1]/span[1]/text()").extract_first()
            if resultNums is not None:
                resultNums = int(resultNums)
            else:
                cookies = random.choice(self.cookies)
                data =  Co.request_from_my_url1(start,end,page)
                return scrapy.FormRequest('http://pe.pedata.cn/getListMa.action',
                                         cookies=cookies,
                                         headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                         formdata=data,
                                         meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                         priority = 5,
                                         callback = self.MaListParse,
                                         dont_filter = True
                                         )
        else:
            # print(response.text)
            data =  Co.request_from_my_url1(start,end,page)
            cookies = random.choice(self.cookies)
            return scrapy.FormRequest('http://pe.pedata.cn/getListMa.action',
                                     cookies=cookies,
                                     headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                     formdata=data,
                                     meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                     priority = 5,
                                     callback = self.MaListParse,
                                     dont_filter = True
                                     )
        print(start, end, page, resultNums)
#        with open("1.html",'w',encoding="utf-8") as f:
#            f.write(response.text)
        configs_x = [{'n':'并购方','En':'Acquirer','t':'xpath_join','v':'td[1]/a/text()','dt':''},
                     {'n':'并购方ID','En':'Acquirer_ID','t':'xpath_join','v':'td[1]/a/@href','dt':''},
                     {'n':'被并购方','En':'merged','t':'xpath_join','v':'td[2]/a/text()','dt':''},
                     {'n':'被并购方ID','En':'merged_ID','t':'xpath_join','v':'td[2]/a/@href','dt':''},
                     ]
        configs_y = [{'n':'并购事件ID','En':'event_ID','t':'xpath_join','v':'td[1]/a/@href','dt':''},
                     
                     ]
        
        configs_z = [{'n':'行业(清科)','En':'Profession_qk','t':'xpath_first','v':'td[3]/@title | td[3]/text()','dt':''},
                     {'n':'地区','En':'location','t':'xpath_first','v':'td[4]/@title | td[4]/text()','dt':''},
                     {'n':'并购状态','En':'Merger_status','t':'xpath_first','v':'td[5]/@title |td[5]/text()','dt':''},
                     {'n':'并购开始时间','En':'Merger_start_date','t':'xpath_first','v':'td[6]/text() | td[6]/@title','dt':''},
                     {'n':'并购结束时间','En':'Merger_end_date','t':'xpath_first','v':'td[7]/text() | td[7]/@title','dt':''},
                     {'n':'并购金额(M)','En':'Merger_Money','t':'xpath_first','v':'td[8]/@title | td[8]/text()','dt':''},
                     {'n':'股权','En':'stock_right','t':'xpath_first','v':'td[10]/@title | td[9]/text()','dt':''},
                     {'n':'是否VC/PE支持','En':'Support_VS_PE','t':'xpath_first','v':'td[11]/@title | td[11]/text()','dt':''},
                     {'n':'是否跨国并购','En':'transnational_merger','t':'xpath_first','v':'td[12]/@title | td[12]/text()','dt':''},
                     {'n':'并购类型','En':'Merger_type','t':'xpath_first','v':'td[13]/@title | td[13]/text()','dt':''},
                     {'n':'行业(国标)','En':'Profession_international','t':'xpath_first','v':'td[14]/@title | td[14]/text()','dt':''},
                     {'n':'行业(证监会)','En':'Profession_Csrc','t':'xpath_first','v':'td[15]/@title | td[15]/text()','dt':''},
                     {'n':'企业估值(M)','En':'Business_valuation','t':'xpath_first','v':'td[16]/text() | td[16]/@title','dt':''}
                     ]
        tree1 = response.xpath("//div[@class='leftTableDivID float_left search_width20']/table/tr")
        tree2 = response.xpath("//div[@class='leftTableDivID float_right search_width20']/table/tr")
        tree3 = response.xpath("//div[@id='rightBodyDivID']/div/table/tr")
        for x,y,z in zip(tree1,tree2,tree3):
            result = dict()
            for config in configs_x:
                result[config['En']] = S.select_content(x,config)
                result[config['En']] = S.replace_all(result[config['En']])
            for config in configs_y:
                result[config['En']] = S.select_content(y,config)
                result[config['En']] = S.replace_all(result[config['En']])
            for config in configs_z:
                result[config['En']] = S.select_content(z,config)
                result[config['En']] = S.replace_all(result[config['En']])
            for i in ['Acquirer_ID','event_ID','merged_ID']:
                result[i] = result[i].split('=')[-1] if hasattr(result[i],'split') else None
            item['result'] = result
            item['db'] = 'dbo.Pedata_Ma'
            item['keys'] = ['event_ID']
            yield item
        if page < resultNums/25:
            page+=1
            cookies = random.choice(self.cookies)
            data = Co.request_from_my_url2(start,end,page,resultNums=resultNums)
            yield scrapy.FormRequest('http://pe.pedata.cn/getListMa.action',
                                      cookies=cookies,
                                      headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                      formdata=data,
                                      meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                      priority = 5,
                                      callback = self.MaListParse
                                      )  
    def ExitListParse(self, response):
        item = PedataItem()
        result = {}
        page = response.meta['page']
        start = response.meta['start']
        end = response.meta['end']
        result['start']=start
        result['endtime']=end
        result['page'] = page
        resultNums = response.meta['resultNums']
        if response.status ==200 and response.meta['resultNums'] is not None:
            resultNums = response.meta['resultNums']
        elif response.status ==200:
            resultNums = response.xpath("//div[@class='search_result']/div[1]/p[1]/span[1]/text()").extract_first()
            if resultNums is not None:
                resultNums = int(resultNums)
            else:
                cookies = random.choice(self.cookies)
                data =  Co.request_from_my_url3(start,end,page)
                return scrapy.FormRequest('http://pe.pedata.cn/getListExit.action',
                                         cookies=cookies,
                                         headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                         formdata=data,
                                         meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                         callback = self.InvestListParse,
                                         dont_filter = True
                                         )
        else:
            # print(response.text)
            data =  Co.request_from_my_url3(start,end,page)
            cookies = random.choice(self.cookies)
            return scrapy.FormRequest('http://pe.pedata.cn/getListExit.action',
                                     cookies=cookies,
                                     headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                     formdata=data,
                                     meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                     callback = self.InvestListParse,
                                     dont_filter = True
                                     )
        print(start, end, page, resultNums)
#        with open('1.html','w+',encoding='utf-8') as f:
#            f.write(response.text)
        configs_x = [{'n':'机构','En':'Org','t':'xpath_join','v':'td[1]/a/text()','dt':''},
                     {'n':'机构ID','En':'Org_ID','t':'xpath_join','v':'td[1]/a/@href','dt':''},
                     {'n':'基金','En':'Fund','t':'xpath_join','v':'td[2]/a/text()','dt':''},
                     {'n':'基金ID','En':'Fund_ID','t':'xpath_join','v':'td[2]/a/@href','dt':''},
                     {'n':'企业','En':'Company','t':'xpath_join','v':'td[3]/a/text()','dt':''},
                     {'n':'企业ID','En':'Company_ID','t':'xpath_join','v':'td[3]/a/@href','dt':''}
                     ]
        configs_y = [{'n':'退出事件ID','En':'Exit_event_ID','t':'xpath_join','v':'td[1]/a/@href','dt':''},
                     
                     ]
        
        configs_z = [{'n':'行业(清科)','En':'Profession_qk','t':'xpath_first','v':'td[3]/@title | td[3]/text()','dt':''},
                     {'n':'地区','En':'location','t':'xpath_first','v':'td[4]/@title | td[4]/text()','dt':''},
                     {'n':'退出时间','En':'Exit_data','t':'xpath_first','v':'td[5]/@title |td[5]/text()','dt':''},
                     {'n':'退出方式','En':'Exit_way','t':'xpath_first','v':'td[6]/text() | td[6]/@title','dt':''},
                     {'n':'账面回报(倍数)','En':'yield_ratio','t':'xpath_first','v':'td[7]/text() | td[7]/@title','dt':''},
                     {'n':'内部收益率','En':'inside_yield','t':'xpath_first','v':'td[8]/@title | td[8]/text()','dt':''},
                     {'n':'回报金额(USD M)','En':'yield_Money','t':'xpath_first','v':'td[9]/@title | td[9]/text()','dt':''},
                     {'n':'国有股转持','En':'transfer_stateowned_shares','t':'xpath_first','v':'td[11]/@title | td[11]/text()','dt':''},
                     {'n':'交易所','En':'exchange','t':'xpath_first','v':'td[12]/@title | td[12]/text()','dt':''},
                     {'n':'行业(国标)','En':'Profession_international','t':'xpath_first','v':'td[13]/@title | td[13]/text()','dt':''},
                     {'n':'行业(证监会)','En':'Profession_Csrc','t':'xpath_first','v':'td[14]/@title | td[14]/text()','dt':''}
                     ]
        tree1 = response.xpath("//div[@class='leftTableDivID float_left search_width20']/table/tr")
        tree2 = response.xpath("//div[@class='leftTableDivID float_right search_width20']/table/tr")
        tree3 = response.xpath("//div[@id='rightBodyDivID']/div/table/tr")
        for x,y,z in zip(tree1,tree2,tree3):
            result = dict()
            for config in configs_x:
                result[config['En']] = S.select_content(x,config)
                result[config['En']] = S.replace_all(result[config['En']])
            for config in configs_y:
                result[config['En']] = S.select_content(y,config)
                result[config['En']] = S.replace_all(result[config['En']])
            for config in configs_z:
                result[config['En']] = S.select_content(z,config)
                result[config['En']] = S.replace_all(result[config['En']])
            for i in ['Company_ID','Exit_event_ID','Fund_ID','Org_ID']:
                result[i] = result[i].split('=')[-1] if hasattr(result[i],'split') else None
            item['result'] = result
            item['db'] = 'dbo.Pedata_ExitEvent'
            item['keys'] = ['Exit_event_ID']
            yield item
        if page < resultNums/25:
            page+=1
            cookies = random.choice(self.cookies)
            data = Co.request_from_my_url3(start,end,page,resultNums=resultNums)
            yield scrapy.FormRequest('http://pe.pedata.cn/getListExit.action',
                                      cookies=cookies,
                                      headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                      formdata=data,
                                      meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                      priority = 5,
                                      callback = self.InvestListParse
                                      )  
    def NeeqListParse(self, response):
        item = PedataItem()
        result = {}
        page = response.meta['page']
        start = response.meta['start']
        end = response.meta['end']
        result['start']=start
        result['endtime']=end
        result['page'] = page
        resultNums = response.meta['resultNums']
        if response.status ==200 and response.meta['resultNums'] is not None:
            resultNums = response.meta['resultNums']
        elif response.status ==200:
            resultNums = response.xpath("//div[@class='search_result']/div[1]/p[1]/span[1]/text()").extract_first()
            if resultNums is not None:
                resultNums = int(resultNums)
            else:
                cookies = random.choice(self.cookies)
                data =  Co.request_from_my_url4(start,end,page)
                return scrapy.FormRequest('http://pe.pedata.cn/getListNeeqList.action',
                                         cookies=cookies,
                                         headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                         formdata=data,
                                         meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                         priority = 5,
                                         callback = self.NeeqListParse,
                                         DONT_FILTER=True,
                                         dont_filter = True
                                         )
        else:
            # print(response.text)
            data =  Co.request_from_my_url4(start,end,page)
            cookies = random.choice(self.cookies)
            return scrapy.FormRequest('http://pe.pedata.cn/getListNeeqList.action',
                                     cookies=cookies,
                                     headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                     formdata=data,
                                     meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                     priority = 5,
                                     callback = self.NeeqListParse,
                                     dont_filter = True
                                     )
        print(start, end, page, resultNums)
#        with open('1.html','w+',encoding='utf-8') as f:
#            f.write(response.text)
        configs_x = [{'n':'企业名称','En':'Company_name','t':'xpath_join','v':'td[1]/a/text()','dt':''},
                     {'n':'企业ID','En':'Company_ID','t':'xpath_join','v':'td[1]/a/@href','dt':''}
                     ]
        configs_y = [{'n':'新三板上市事件ID','En':'Neeq_event_ID','t':'xpath_join','v':'td[1]/a/@href','dt':''},
                     
                     ]
        
        configs_z = [{'n':'挂牌时间','En':'Listing_date','t':'xpath_first','v':'td[2]/@title | td[2]/text()','dt':''},
                     {'n':'行业(清科)','En':'Profession_qk','t':'xpath_first','v':'td[3]/@title | td[3]/text()','dt':''},
                     {'n':'地区','En':'location','t':'xpath_first','v':'td[4]/@title |td[4]/text()','dt':''},
                     {'n':'股票代码','En':'stock_code','t':'xpath_first','v':'td[5]/text() | td[5]/@title','dt':''},
                     {'n':'转让方式','En':'transferring','t':'xpath_first','v':'td[6]/text() | td[6]/@title','dt':''},
                     {'n':'市场分层','En':'Market','t':'xpath_first','v':'td[7]/@title | td[7]/text()','dt':''},
                     {'n':'股本','En':'equity','t':'xpath_first','v':'td[8]/@title | td[8]/text()','dt':''},
                     {'n':'是否VC/PE支持','En':'Support_VS_PE','t':'xpath_first','v':'td[9]/@title | td[9]/text()','dt':''},
                     {'n':'承销商','En':'Underwriter','t':'xpath_first','v':'td[10]/@title | td[10]/text()','dt':''},
                     {'n':'会计师事务所','En':'accounting_firm','t':'xpath_first','v':'td[11]/@title | td[11]/text()','dt':''},
                     {'n':'律师事务所','En':'Law_firm','t':'xpath_first','v':'td[12]/@title | td[12]/text()','dt':''},
                     {'n':'行业(国标)','En':'Profession_international','t':'xpath_first','v':'td[13]/@title | td[13]/text()','dt':''},
                     {'n':'行业(证监会)','En':'Profession_Csrc','t':'xpath_first','v':'td[14]/@title | td[14]/text()','dt':''}
                     ]
        tree1 = response.xpath("//div[@class='leftTableDivID float_left search_width20']/table/tr")
        tree2 = response.xpath("//div[@class='leftTableDivID float_right search_width20']/table/tr")
        tree3 = response.xpath("//div[@id='rightBodyDivID']/div/table/tr")
        for x,y,z in zip(tree1,tree2,tree3):
            result = dict()
            for config in configs_x:
                result[config['En']] = S.select_content(x,config)
                result[config['En']] = S.replace_all(result[config['En']])
            for config in configs_y:
                result[config['En']] = S.select_content(y,config)
                result[config['En']] = S.replace_all(result[config['En']])
            for config in configs_z:
                result[config['En']] = S.select_content(z,config)
                result[config['En']] = S.replace_all(result[config['En']])
            for i in ['Company_ID','Neeq_event_ID']:
                result[i] = result[i].split('=')[-1] if hasattr(result[i],'split') else None
            item['result'] = result
            item['db'] = 'dbo.Pedata_NeeqEvent'
            item['keys'] = ['Neeq_event_ID']
            if result['Company_name']:
                yield item
        if page < resultNums/25:
            page+=1
            cookies = random.choice(self.cookies)
            data = Co.request_from_my_url4(start,end,page,resultNums=resultNums)
            yield scrapy.FormRequest('http://pe.pedata.cn/getListNeeqList.action',
                                      cookies=cookies,
                                      headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                      formdata=data,
                                      meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                      priority = 5,
                                      callback = self.NeeqListParse
                                      )
    def FundListParse(self, response):
        item = PedataItem()
        result = {}
        page = response.meta['page']
        start = response.meta['start']
        end = response.meta['end']
        result['start']=start
        result['endtime']=end
        result['page'] = page
        resultNums = response.meta['resultNums']
        if response.status ==200 and response.meta['resultNums'] is not None:
            resultNums = response.meta['resultNums']
        elif response.status ==200:
            resultNums = response.xpath("//div[@class='search_result']/div[1]/p[1]/span[1]/text()").extract_first()
            if resultNums is not None:
                resultNums = int(resultNums)
            else:
                cookies = random.choice(self.cookies)
                data =  Co.request_from_my_url5(start,end,page)
                return scrapy.FormRequest('http://pe.pedata.cn/getListFund.action',
                                         cookies=cookies,
                                         headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                         formdata=data,
                                         meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                         priority = 5,
                                         callback = self.FundListParse,
                                         dont_filter = True
                                         )
        else:
            # print(response.text)
            data =  Co.request_from_my_url5(start,end,page)
            cookies = random.choice(self.cookies)
            return scrapy.FormRequest('http://pe.pedata.cn/getListFund.action',
                                     cookies=cookies,
                                     headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                     formdata=data,
                                     meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                     priority = 5,
                                     callback = self.FundListParse,
                                     dont_filter = True
                                     )
        print(start, end, page, resultNums)
#        with open('1.html','w+',encoding='utf-8') as f:
#            f.write(response.text)
        configs_x = [{'n':'基金简称','En':'Fund_name','t':'xpath_join','v':'td[1]/a/text()','dt':''},
                     {'n':'基金简称ID','En':'Fund_ID','t':'xpath_join','v':'td[1]/a/@href','dt':''},
                     {'n':'管理机构','En':'Manager_Org','t':'xpath_join','v':'td[2]/a/text()','dt':''},
                     {'n':'管理机构ID','En':'Manager_Org_ID','t':'xpath_join','v':'td[2]/a/@href','dt':''}
                     ]
        
        configs_z = [{'n':'成立时间','En':'setup_date','t':'xpath_first','v':'td[3]/@title | td[3]/text()','dt':''},
                     {'n':'注册地区','En':'Registered_area','t':'xpath_first','v':'td[4]/@title |td[4]/text()','dt':''},
                     {'n':'总部地区','En':'Headquarters_area','t':'xpath_first','v':'td[5]/text() | td[5]/@title','dt':''},
                     {'n':'基金类型','En':'fund_type','t':'xpath_first','v':'td[6]/text() | td[6]/@title','dt':''},
                     {'n':'资本类型','En':'Capital_type','t':'xpath_first','v':'td[7]/@title | td[7]/text()','dt':''},
                     {'n':'募集状态','En':'Recruitment_status','t':'xpath_first','v':'td[8]/@title | td[8]/text()','dt':''},
                     {'n':'目标规模(M)','En':'Target_size','t':'xpath_first','v':'td[9]/@title | td[9]/text()','dt':''},
                     {'n':'基金币种','En':'Fund_currency','t':'xpath_first','v':'td[10]/@title | td[10]/text()','dt':''},
                     {'n':'开始募集时间','En':'Recruitment_start_date','t':'xpath_first','v':'td[11]/@title | td[11]/text()','dt':''},
                     {'n':'是否备案','En':'is_record','t':'xpath_first','v':'td[12]/@title | td[12]/text()','dt':''},
                     {'n':'组织形式','En':'Organization_form','t':'xpath_first','v':'td[13]/@title | td[13]/text()','dt':''},
                     {'n':'累计投资事件总数','En':'Investment_Event_Total','t':'xpath_first','v':'td[14]/@title | td[14]/text()','dt':''},
                     {'n':'累计退出事件总数','En':'Exit_Event_Total','t':'xpath_first','v':'td[15]/@title | td[14]/text()','dt':''}
                     ]
        tree1 = response.xpath("//div[@class='leftTableDivID float_left search_width20']/table/tr")
        #tree2 = response.xpath("//div[@class='leftTableDivID float_right search_width20']/table/tr")
        tree3 = response.xpath("//div[@id='rightBodyDivID']/div/table/tr")
        for x,z in zip(tree1,tree3):
            result = dict()
            for config in configs_x:
                result[config['En']] = S.select_content(x,config)
                result[config['En']] = S.replace_all(result[config['En']])
            for config in configs_z:
                result[config['En']] = S.select_content(z,config)
                result[config['En']] = S.replace_all(result[config['En']])
            for i in ['Fund_ID','Manager_Org_ID']:
                result[i] = result[i].split('=')[-1] if hasattr(result[i],'split') else None
            item['result'] = result
            item['db'] = 'dbo.Pedata_Fund'
            item['keys'] =  ['Fund_ID']
            if result['Fund_ID']:
                yield item
        if page < resultNums/25:
            page+=1
            cookies = random.choice(self.cookies)
            data = Co.request_from_my_url5(start,end,page,resultNums=resultNums)
            yield scrapy.FormRequest('http://pe.pedata.cn/getListFund.action',
                                      cookies=cookies,
                                      headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                      formdata=data,
                                      meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                      priority = 5,
                                      callback = self.FundListParse,
                                      dont_filter = True
                                      )
    def IpoListParse(self, response):
        item = PedataItem()
        result = {}
        page = response.meta['page']
        start = response.meta['start']
        end = response.meta['end']
        result['start']=start
        result['endtime']=end
        result['page'] = page
        resultNums = response.meta['resultNums']
        if response.status ==200 and response.meta['resultNums'] is not None:
            resultNums = response.meta['resultNums']
        elif response.status ==200:
            resultNums = response.xpath("//div[@class='search_result']/div[1]/p[1]/span[1]/text()").extract_first()
            if resultNums is not None:
                resultNums = int(resultNums)
            else:
                cookies = random.choice(self.cookies)
                data =  Co.request_from_my_url6(start,end,page)
                return scrapy.FormRequest('http://pe.pedata.cn/getListIpo.action',
                                         cookies=cookies,
                                         headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                         formdata=data,
                                         meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                         priority = 5,
                                         callback = self.IpoListParse,
                                         dont_filter = True
                                         )
        else:
            # print(response.text)
            data =  Co.request_from_my_url6(start,end,page)
            cookies = random.choice(self.cookies)
            return scrapy.FormRequest('http://pe.pedata.cn/getListIpo.action',
                                     cookies=cookies,
                                     headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                     formdata=data,
                                     meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                     priority = 5,
                                     callback = self.IpoListParse,
                                     dont_filter = True
                                     )
        print(start, end, page, resultNums)
#        with open('1.html','w+',encoding='utf-8') as f:
#            f.write(response.text)
        configs_x = [{'n':'企业名称','En':'Company_name','t':'xpath_join','v':'td[1]/a/text()','dt':''},
                     {'n':'企业ID','En':'Company_id','t':'xpath_join','v':'td[1]/a/@href','dt':''}
                     ]
        configs_y = [{'n':'上市事件ID','En':'Listing_ID','t':'xpath_join','v':'td[1]/a/@href','dt':''}
                     ]
        configs_z = [{'n':'交易所','En':'Exchange','t':'xpath_first','v':'td[2]/@title | td[2]/text()','dt':''},
                     {'n':'上市时间','En':'Listing_date','t':'xpath_first','v':'td[3]/@title | td[3]/text()','dt':''},
                     {'n':'行业(清科)','En':'Profession_qk','t':'xpath_first','v':'td[4]/@title |td[4]/text()','dt':''},
                     {'n':'地区','En':'location','t':'xpath_first','v':'td[5]/text() | td[5]/@title','dt':''},
                     {'n':'股票代码','En':'stock_code','t':'xpath_first','v':'td[6]/text() | td[6]/@title','dt':''},
                     {'n':'筹资额(M)','En':'capital','t':'xpath_first','v':'td[7]/@title | td[7]/text()','dt':''},
                     {'n':'市盈率','En':'Price_earnings_ratio','t':'xpath_first','v':'td[8]/@title | td[8]/text()','dt':''},
                     {'n':'VC/PE支持的IPO','En':'Support_VS_PE','t':'xpath_first','v':'td[9]/@title | td[9]/text()','dt':''},
                     {'n':'承销商','En':'Underwriter','t':'xpath_first','v':'td[10]/@title | td[10]/text()','dt':''},
                     {'n':'会计师事务所','En':'accounting_firm','t':'xpath_first','v':'td[11]/@title | td[11]/text()','dt':''},
                     {'n':'律师事务所','En':'Law_firm','t':'xpath_first','v':'td[12]/@title | td[12]/text()','dt':''},
                     {'n':'行业(国标)','En':'Profession_international','t':'xpath_first','v':'td[13]/@title | td[13]/text()','dt':''},
                     {'n':'行业(证监会)','En':'Profession_Csrc','t':'xpath_first','v':'td[14]/@title | td[14]/text()','dt':''},
                     ]
        tree1 = response.xpath("//div[@class='leftTableDivID float_left search_width20']/table/tr")
        tree2 = response.xpath("//div[@class='leftTableDivID float_right search_width20']/table/tr")
        tree3 = response.xpath("//div[@id='rightBodyDivID']/div/table/tr")
        for x,y,z in zip(tree1,tree2,tree3):
            result = dict()
            for config in configs_x:
                result[config['En']] = S.select_content(x,config)
                result[config['En']] = S.replace_all(result[config['En']])
            for config in configs_y:
                result[config['En']] = S.select_content(y,config)
                result[config['En']] = S.replace_all(result[config['En']])
            for config in configs_z:
                result[config['En']] = S.select_content(z,config)
                result[config['En']] = S.replace_all(result[config['En']])
            for i in ['Company_id','Listing_ID']:
                result[i] = result[i].split('=')[-1] if hasattr(result[i],'split') else None
            item['result'] = result
            item['db'] = 'Pedata_IpoEvent'
            item['keys'] = ['Listing_ID']
            if result['Listing_ID']:
                yield item
        if page < resultNums/25:
            page+=1
            cookies = random.choice(self.cookies)
            data = Co.request_from_my_url6(start,end,page,resultNums=resultNums)
            yield scrapy.FormRequest('http://pe.pedata.cn/getListIpo.action',
                                      cookies=cookies,
                                      headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                      formdata=data,
                                      meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                      priority = 5,
                                      callback = self.IpoListParse
                                      )
    def EpListParse(self, response):
#        item = PedataItem()
        result = {}
        page = response.meta['page']
        start = response.meta['start']
        end = response.meta['end']
        result['start']=start
        result['endtime']=end
        result['page'] = page
        resultNums = response.meta['resultNums']
        if response.status ==200 and response.meta['resultNums'] is not None:
            resultNums = response.meta['resultNums']
        elif response.status ==200:
            resultNums = response.xpath("//div[@class='search_result']/div[1]/p[1]/span[1]/text()").extract_first()
            if resultNums is not None:
                resultNums = int(resultNums)
            else:
                cookies = random.choice(self.cookies)
                data =  Co.request_from_my_url7(start,end,page)
                return scrapy.FormRequest('http://pe.pedata.cn/getListEp.action',
                                         cookies=cookies,
                                         headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                         formdata=data,
                                         meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                         priority = 5,
                                         callback = self.EpListParse,
                                         dont_filter = True
                                         )
        else:
            # print(response.text)
            data =  Co.request_from_my_url7(start,end,page)
            cookies = random.choice(self.cookies)
            return scrapy.FormRequest('http://pe.pedata.cn/getListEp.action',
                                     cookies=cookies,
                                     headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                     formdata=data,
                                     meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                     priority = 5,
                                     callback = self.EpListParse,
                                     dont_filter = True
                                     )
        print(start, end, page, resultNums)
        config = {'n':'','En':'ep_id','t':'xpath_first','v':'td[1]/a/@href','dt':''}
        for info in response.xpath("//div[@class='leftTableDivID float_left search_width20']/table//tr"):
            ep_id = S.select_content(info,config)
            url = response.urljoin(ep_id)
            cookies = random.choice(self.cookies)
            yield scrapy.Request(url,
                                 callback=self.EpInfoParse,
                                 headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                 cookies = cookies,
                                 priority = 1
                                 )
        if page < resultNums/25:
            page+=1
            cookies = random.choice(self.cookies)
            data = Co.request_from_my_url7(start,end,page,resultNums=resultNums)
            yield scrapy.FormRequest('http://pe.pedata.cn/getListEp.action',
                                      cookies=cookies,
                                      headers={"User-Agent": generate_user_agent(os=('mac', 'win'))},
                                      formdata=data,
                                      meta={"start": start, "end": end, "page": page, "resultNums": resultNums},
                                      priority = 5,
                                      callback = self.EpListParse
                                      )
    def EpInfoParse(self, response):
        item = PedataItem()
        result = {}
        result['org_id'] = response.url.split("=")[-1]
        if "Login timeout" in response.text or "setTimeout" in response.text:
            cookies = random.choice(self.cookies)
            return scrapy.Request(response.url,
                                 method = "GET",
                                 cookies = cookies,
                                 headers = {"User-Agent":generate_user_agent(os=('mac', 'win'))},
                                 priority = 1,
                                 dont_filter = True)
            
        if response.status != 200:
            cookies = random.choice(self.cookies)
            return scrapy.Request(response.url,
                                 method = "GET",
                                 cookies = cookies,
                                 headers = {"User-Agent":generate_user_agent(os=('mac', 'win'))},
                                 priority = 1,
                                 dont_filter = True)
        configs = [{'n':"中文全称","En":"org_Full_name","v":"//span[@class='detail_title24']/text()","t":"xpath_join","dt":""},
                   {'n':"中文简称","En":"org_name","v":"//div[contains(text(),'中文简称：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"行业","En":"industry","v":"//div[contains(text(),'行业：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"成立时间","En":"set_up_time","v":"//div[contains(text(),'成立时间：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"公司类型","En":"company_type","v":"//div[contains(text(),'公司类型：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"注册地区","En":"Registered_area","v":"//div[contains(text(),'注册地区：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"公司总部","En":"headquarters","v":"//div[contains(text(),'公司总部：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"是否国有背景","En":"State_background","v":"//div[contains(text(),'是否国有背景：')]/following-sibling::div[1]/text()","t":"xpath_first","dt":""},
                   {'n':"企业状态","En":"company_status","v":"//div[contains(text(),'企业状态：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"法人代表","En":"Legal_representative","v":"//div[contains(text(),'法人代表：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"组织机构代码","En":"Organization_code","v":"//div[contains(text(),'组织机构代码：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"工商注册号","En":"registration_number","v":"//div[contains(text(),'工商注册号：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"中国-地址","En":"China_address","v":"//div[contains(text(),'中国') and @class='detail_onebox_title_top']/following-sibling::div[1]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"中国-邮编","En":"China_Postal_Code","v":"//div[contains(text(),'中国') and @class='detail_onebox_title_top']/following-sibling::div[2]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"中国-联系人","En":"China_Contacts","v":"//div[contains(text(),'中国') and @class='detail_onebox_title_top']/following-sibling::div[3]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"中国-联系电话","En":"China_Contact_number","v":"//div[contains(text(),'中国') and @class='detail_onebox_title_top']/parent::div/following-sibling::div[1]/div[2]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"中国-传真","En":"China_fax","v":"//div[contains(text(),'中国') and @class='detail_onebox_title_top']/parent::div/following-sibling::div[1]/div[3]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"中国-邮箱","En":"China_email","v":"//div[contains(text(),'中国') and @class='detail_onebox_title_top']/parent::div/following-sibling::div[1]/div[4]/div[2]/text()","t":"xpath_join","dt":""},
                   {'n':"清科行业分类","En":"Profession_qk","v":"//div[contains(text(),'清科行业分类：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"国标行业分类","En":"Profession_international","v":"//div[contains(text(),'国标行业分类：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""},
                   {'n':"证监会行业分类","En":"Profession_Csrc","v":"//div[contains(text(),'证监会行业分类：')]/following-sibling::div[1]/text()","t":"xpath_join","dt":""}
                   
                   ]
        html = S.replace_invalid_html_char(response.text)
        res = scrapy.Selector(text = html)
        result = dict()
        for config in configs:
            result[config['En']] = S.select_content(res, config)
            result[config['En']] = S.replace_all(result[config['En']])
        result['org_id'] = response.url.split('=')[-1]
        item['result'] = result
        item['db'] = 'Pedata_Ep'
        item['keys'] = ['org_id']
        if result['org_Full_name']:
            yield item
        else:
            print(response.text)