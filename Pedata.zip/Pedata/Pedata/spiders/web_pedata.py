# -*- coding: utf-8 -*-
import scrapy
from user_agent import generate_user_agent as ua
import re
from .config import WebConfigs as Configs
from .myselector import Selector as S


class WebPedataSpider(scrapy.Spider):
    name = "web_pedata"
    allowed_domains = ["pedata.cn"]
    start_urls = ['http://ep.pedata.cn/',
                  'http://person.pedata.cn/',
                  'http://fund.pedata.cn/',
                  'http://exit.pedata.cn/',
                  'http://ma.pedata.cn/',
                  'http://ipo.pedata.cn/',
                  'http://invest.pedata.cn/',
                  'http://org.pedata.cn/']
    cookies = {}
    OrgtotalPage = 521
    investtotalPage = 1500
    ipototalPage = 715
    setdicts = set()
    custom_settings = {'DOWNLOADER_MIDDLEWARES': {
                        'Pedata.middlewares.RotateUserAgentMiddleware':401,
#                        'Pedata.middlewares.ProxyMiddleware':700,
                        },
                        'CONCURRENT_REQUESTS' :1,
                        'DOWNLOAD_DELAY':2,
                        'DEPTH_PRIORITY' : 1,
                        }
    def start_requests(self):
        for url in self.start_urls:
            if url == 'http://org.pedata.cn/':
                yield scrapy.Request(url,
                                     headers = {'User-Agent':ua(os=('win','mac','linux'))},
                                     callback=self.orgListParse,
                                     meta = {'page':1},
                                     priority=10,
                                     dont_filter=True)
            if url == 'http://invest.pedata.cn/':
                yield scrapy.Request(url,
                                     headers = {'User-Agent':ua(os=('win','mac','linux'))},
                                     callback=self.investListParse,
                                     meta = {'page':1},
                                     priority=10,
                                     dont_filter=True)
            if url == 'http://ipo.pedata.cn/':
                yield scrapy.Request(url,
                                     headers = {'User-Agent':ua(os=('win','mac','linux'))},
                                     callback=self.ipoListParse,
                                     meta = {'page':1},
                                     priority=10,
                                     dont_filter=True)
                
            if url == 'http://ma.pedata.cn/':
                yield scrapy.Request(url,
                                     headers = {'User-Agent':ua(os=('win','mac','linux'))},
                                     callback=self.maListParse,
                                     meta = {'page':1},
                                     priority=10,
                                     dont_filter=True)
            if url == 'http://fund.pedata.cn/':
                yield scrapy.Request(url,
                                     headers = {'User-Agent':ua(os=('win','mac','linux'))},
                                     callback=self.fundListParse,
                                     meta = {'page':1},
                                     priority=10,
                                     dont_filter=True)
            if url == 'http://person.pedata.cn/':
                yield scrapy.Request(url,
                                     headers = {'User-Agent':ua(os=('win','mac','linux'))},
                                     callback=self.personListParse,
                                     meta = {'page':1},
                                     priority=50,
                                     dont_filter=True)
            if url == 'http://ep.pedata.cn/':
                yield scrapy.Request(url,
                                     headers = {'User-Agent':ua(os=('win','mac','linux'))},
                                     callback=self.epListParse,
                                     meta = {'page':1},
                                     priority=50,
                                     dont_filter=True)
    def parse(self, response ):
        pass
    def orgListParse(self, response):
        page = response.meta['page']
        if 'setTimeout' in response.text:
            yield scrapy.Request(response.url,callback=self.orgListParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=10,dont_filter=True)
            return False
        orgUrlList = re.findall('https?:\/\/org\.pedata\.cn\/\d+?\.html',response.text)
        if page == 1:
            #更新总页数
            self.OrgtotalPage = int(re.search("totalPage\s*?=\s*?\'?(\d+)\'?",response.text).group(1))
        
        for url in orgUrlList:
            if url not in self.setdicts:
                self.setdicts.add(url)
                yield scrapy.Request(url,callback=self.OrgInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True)
        if page<=self.OrgtotalPage:
            page+=1
            NextUrl = 'http://org.pedata.cn/list_{page}_0_0_0_0_0.html'.format(page=page)
            yield scrapy.Request(NextUrl,callback=self.orgListParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=15,dont_filter=True)
    def investListParse(self, response):
        page = response.meta['page']
        if 'setTimeout' in response.text:
            yield scrapy.Request(response.url,callback=self.investListParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=10,dont_filter=True)
            return False
        investUrlList = re.findall('https?:\/\/invest\.pedata\.cn\/\d+?\.html',response.text)
        if page == 1:
            #更新总页数
            self.investtotalPage = int(re.search("totalPage\s*?=\s*?\'?(\d+)\'?",response.text).group(1))
        
        for url in investUrlList:
            if url not in self.setdicts:
                self.setdicts.add(url)
                yield scrapy.Request(url,callback=self.investInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True)       
        if page<=self.OrgtotalPage:
            page+=1
            NextUrl = 'http://invest.pedata.cn/list_{page}_0_0_0_0.html'.format(page=page)
            yield scrapy.Request(NextUrl,callback=self.investListParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=15,dont_filter=True)
    def ipoListParse(self, response):
        page = response.meta['page']
        if 'setTimeout' in response.text:
            yield scrapy.Request(response.url,callback=self.ipoListParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=10,dont_filter=True)
            return False
        investUrlList = re.findall('https?:\/\/ipo\.pedata\.cn\/\d+?\.html',response.text)
        if page == 1:
            #更新总页数
            self.ipototalPage = int(re.search("totalPage\s*?=\s*?\'?(\d+)\'?",response.text).group(1))
        
        for url in investUrlList:
            if url not in self.setdicts:
                self.setdicts.add(url)
                yield scrapy.Request(url,callback=self.ipoInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True)       
        if page<=self.OrgtotalPage:
            page+=1
            NextUrl = 'http://ipo.pedata.cn/list_{page}_0_0_0_0.html'.format(page=page)
            yield scrapy.Request(NextUrl,callback=self.ipoListParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=15,dont_filter=True)
    def maListParse(self, response):
        page = response.meta['page']
        if 'setTimeout' in response.text:
            yield scrapy.Request(response.url,callback=self.ipoListParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=10,dont_filter=True)
            return False
        maUrlList = re.findall('https?:\/\/ma\.pedata\.cn\/\d+?\.html',response.text)
        if page == 1:
            #更新总页数
            self.matotalPage = int(re.search("totalPage\s*?=\s*?\'?(\d+)\'?",response.text).group(1))
        
        for url in maUrlList:
            if url not in self.setdicts:
                self.setdicts.add(url)
                yield scrapy.Request(url,callback=self.maInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True)       
        if page<=self.OrgtotalPage:
            page+=1
            NextUrl = 'http://ma.pedata.cn/list_{page}_0_0_0_0.html'.format(page=page)
            yield scrapy.Request(NextUrl,callback=self.ipoListParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=15,dont_filter=True)
    def exitListParse(self, response):
        page = response.meta['page']
        if 'setTimeout' in response.text:
            yield scrapy.Request(response.url,callback=self.exitListParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=10,dont_filter=True)
            return False
        exitUrlList = re.findall('https?:\/\/exit\.pedata\.cn\/\d+?\.html',response.text)
        if page == 1:
            #更新总页数
            self.exittotalPage = int(re.search("totalPage\s*?=\s*?\'?(\d+)\'?",response.text).group(1))
        for url in exitUrlList:
            if url not in self.setdicts:
                self.setdicts.add(url)
                yield scrapy.Request(url,callback=self.exitInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True)       
        if page<=self.exittotalPage:
            page+=1
            NextUrl = 'http://exit.pedata.cn/list_{page}_0_0_0_0.html'.format(page=page)
            yield scrapy.Request(NextUrl,callback=self.exitListParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=15,dont_filter=True)
    def fundListParse(self, response):
        page = response.meta['page']
        if 'setTimeout' in response.text:
            yield scrapy.Request(response.url,callback=self.fundListParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=10,dont_filter=True)
            return False
        fundUrlList = re.findall('https?:\/\/fund\.pedata\.cn\/\d+?\.html',response.text)
        if page == 1:
            #更新总页数
            self.fundtotalPage = int(re.search("totalPage\s*?=\s*?\'?(\d+)\'?",response.text).group(1))
        for url in fundUrlList:
            if url not in self.setdicts:
                self.setdicts.add(url)
                yield scrapy.Request(url,callback=self.fundInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True)       
        if page<=self.fundtotalPage:
            page+=1
            NextUrl = 'http://fund.pedata.cn/list_{page}_0_0_0_0.html'.format(page=page)
            yield scrapy.Request(NextUrl,callback=self.fundListParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=15,dont_filter=True)
    def personListParse(self, response):
        page = response.meta['page']
        if 'setTimeout' in response.text:
            yield scrapy.Request(response.url,callback=self.personListParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=10,dont_filter=True)
            return False
        personUrlList = re.findall('https?:\/\/person\.pedata\.cn\/\d+?\.html',response.text)
        if page == 1:
            #更新总页数
            self.persontotalPage = int(re.search("totalPage\s*?=\s*?\'?(\d+)\'?",response.text).group(1))
        for url in personUrlList:
            if url not in self.setdicts:
                self.setdicts.add(url)
                yield scrapy.Request(url,callback=self.personInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True)   
        if page<=self.persontotalPage:
            page+=1
            NextUrl = 'http://person.pedata.cn/list_{page}_0_0_0.html'.format(page=page)
            yield scrapy.Request(NextUrl,callback=self.personListParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=15,dont_filter=True)
    def epListParse(self, response):
        page = response.meta['page']
        if 'setTimeout' in response.text:
            yield scrapy.Request(response.url,callback=self.epListParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=10,dont_filter=True)
            return False
        epUrlList = re.findall('https?:\/\/ep\.pedata\.cn\/\d+?\.html',response.text)
        if page == 1:
            #更新总页数
            self.eptotalPage = int(re.search("totalPage\s*?=\s*?\'?(\d+)\'?",response.text).group(1))
        
        for url in epUrlList:
            if url not in self.setdicts:
                self.setdicts.add(url)
                yield scrapy.Request(url,callback=self.epInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True)       
        if page<=self.eptotalPage:
            page+=1
            NextUrl = 'http://ep.pedata.cn/list_{page}_0_0_0.html'.format(page=page)
            yield scrapy.Request(NextUrl,callback=self.epListParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=15,dont_filter=True)
    def OrgInfoParse(self, response):
        page = response.meta['page']
        if 'setTimeout' in response.text:
            yield scrapy.Request(response.url,callback=self.OrgInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True)
            return False
        orgUrlList = re.findall('https?:\/\/org\.pedata\.cn\/\d+?\.html',response.text)
        if orgUrlList:
            for url in orgUrlList:
                if url not in self.setdicts:
                    self.setdicts.add(url)
                    yield scrapy.Request(url,callback=self.OrgInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True,errback=None)
        configs = Configs.config_org()
        result = dict()
        for config in configs['data']:
            k= config['En']
            result[k] = S.select_content(response, config)
            result[k] = result[k].split("：")[-1] if hasattr(result[k],'split') else result[k]
            result[k] = S.replace_all(result[k])
        result['Org_ID'] = response.url.split('/')[-1][:-5]
        print(result)
    def investInfoParse(self, response):
        page = response.meta['page']
        if 'setTimeout' in response.text:
            yield scrapy.Request(response.url,callback=self.investInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True)
            return False
        investUrlList = re.findall('https?:\/\/invest\.pedata\.cn\/\d+?\.html',response.text)
        if investUrlList:
            for url in investUrlList:
                if url not in self.setdicts:
                    self.setdicts.add(url)
                    yield scrapy.Request(url,callback=self.investInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True,errback=None)
        configs = Configs.config_invest()
        result = dict()
        for config in configs['data']:
            k= config['En']
            result[k] = S.select_content(response, config)
            result[k] = result[k].split("：")[-1] if hasattr(result[k],'split') else result[k]
            result[k] = S.replace_all(result[k])
        result['invest_ID'] = response.url.split('/')[-1][:-5]
        print(result) 
    def ipoInfoParse(self, response):
        page = response.meta['page']
        if 'setTimeout' in response.text:
            yield scrapy.Request(response.url,callback=self.ipoInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True)
            return False
        investUrlList = re.findall('https?:\/\/ipo\.pedata\.cn\/\d+?\.html',response.text)
        if investUrlList:
            for url in investUrlList:
                if url not in self.setdicts:
                    self.setdicts.add(url)
                    yield scrapy.Request(url,callback=self.ipoInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True,errback=None)
        configs = Configs.config_ipo()
        result = dict()
        for config in configs['data']:
            k= config['En']
            result[k] = S.select_content(response, config)
            result[k] = result[k].split("：")[-1] if hasattr(result[k],'split') else result[k]
            result[k] = S.replace_all(result[k])
        result['ipo_ID'] = response.url.split('/')[-1][:-5]
        print(result)
    def maInfoParse(self, response):
        page = response.meta['page']
        if 'setTimeout' in response.text:
            yield scrapy.Request(response.url,callback=self.maInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True)
            return False
        investUrlList = re.findall('https?:\/\/ma\.pedata\.cn\/\d+?\.html',response.text)
        if investUrlList:
            for url in investUrlList:
                if url not in self.setdicts:
                    self.setdicts.add(url)
                    yield scrapy.Request(url,callback=self.maInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True,errback=None)
        configs = Configs.config_ma()
        result = dict()
        for config in configs['data']:
            k= config['En']
            result[k] = S.select_content(response, config)
            result[k] = result[k].split("：")[-1] if hasattr(result[k],'split') else result[k]
            result[k] = S.replace_all(result[k])
        result['ma_ID'] = response.url.split('/')[-1][:-5]
        print(result)
    def exitInfoParse(self, response):
        page = response.meta['page']
        if 'setTimeout' in response.text:
            yield scrapy.Request(response.url,callback=self.exitInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True)
            return False
        investUrlList = re.findall('https?:\/\/exit\.pedata\.cn\/\d+?\.html',response.text)
        if investUrlList:
            for url in investUrlList:
                if url not in self.setdicts:
                    self.setdicts.add(url)
                    yield scrapy.Request(url,callback=self.exitInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True,errback=None)
        configs = Configs.config_exit()
        result = dict()
        for config in configs['data']:
            k= config['En']
            result[k] = S.select_content(response, config)
            result[k] = result[k].split("：")[-1] if hasattr(result[k],'split') else result[k]
            result[k] = S.replace_all(result[k])
        result['ma_ID'] = response.url.split('/')[-1][:-5]
        print(result)
    
    def fundInfoParse(self, response):
        page = response.meta['page']
        if 'setTimeout' in response.text:
            yield scrapy.Request(response.url,callback=self.fundInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True)
            return False
        fundUrlList = re.findall('https?:\/\/fund\.pedata\.cn\/\d+?\.html',response.text)
        if fundUrlList:
            for url in fundUrlList:
                if url not in self.setdicts:
                    self.setdicts.add(url)
                    yield scrapy.Request(url,callback=self.fundInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True,errback=None)
        configs = Configs.config_fund()
        result = dict()
        for config in configs['data']:
            k= config['En']
            result[k] = S.select_content(response, config)
            result[k] = result[k].split("：")[-1] if hasattr(result[k],'split') else result[k]
            result[k] = S.replace_all(result[k])
        result['fund_ID'] = response.url.split('/')[-1][:-5]
        print(result)
    def personInfoParse(self, response):
        page = response.meta['page']
        if 'setTimeout' in response.text:
            yield scrapy.Request(response.url,callback=self.personInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True)
            return False
        personUrlList = re.findall('https?:\/\/person\.pedata\.cn\/\d+?\.html',response.text)
        
        configs = Configs.config_person()
        result = dict()
        for config in configs['data']:
            k= config['En']
            result[k] = S.select_content(response, config)
            result[k] = result[k].split("：")[-1] if hasattr(result[k],'split') else result[k]
        for config in configs['data']:
            k= config['En']
            result[k] = S.replace_all(result[k])
        result['person_ID'] = response.url.split('/')[-1][:-5]
        print(result)
        if personUrlList:
            for url in personUrlList:
                if url not in self.setdicts:
                    self.setdicts.add(url)
                    yield scrapy.Request(url,callback=self.personInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=1,dont_filter=True,errback=None)
    def epInfoParse(self, response):
        page = response.meta['page']
        if 'setTimeout' in response.text:
            yield scrapy.Request(response.url,callback=self.epInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True)
            return False
        epUrlList = re.findall('https?:\/\/ep\.pedata\.cn\/\d+?\.html',response.text)
        if epUrlList:
            for url in epUrlList:
                if url not in self.setdicts:
                    self.setdicts.add(url)
                    yield scrapy.Request(url,callback=self.epInfoParse,method='Get',headers = {'User-Agent':ua(os=('win','mac','linux'))},body=None,cookies=None,meta={'page':page},priority=5,dont_filter=True,errback=None)
        configs = Configs.config_ep()
        result = dict()
        for config in configs['data']:
            k= config['En']
            result[k] = S.select_content(response, config)
            result[k] = result[k].split("：")[-1] if hasattr(result[k],'split') else result[k]
            result[k] = S.replace_all(result[k])
        result['ep_ID'] = response.url.split('/')[-1][:-5]
        print(result)