# -*- coding: utf-8 -*-
"""
Created on Thu Sep 28 16:00:34 2017

@author: luopx
"""

from selenium import webdriver
import time
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
import pytesseract
from PIL import Image,ImageDraw,ImageChops
import random
import re
import requests
from user_agent import generate_user_agent
from io import BytesIO
import os
class yzm(object):
    def __init__(self):
        pass
    
    

class pedata_register(object):
    def __init__(self):
        self.Driver = webdriver.Chrome()
        self.Driver.set_window_size(1200, 800)
    def openDriver(self,url,xpath_value):
        self.Driver.implicitly_wait(10)
        self.Driver.get(url)
#        WebDriverWait(self.Driver, 30).until(lambda the_driver: the_driver.find_element_by_xpath(xpath_value).is_displayed())
    def click_xpath(self,xpath_value):
#        oldPage = self.Driver.page_source.encode('utf-8').decode("utf-8")
        randMail = self.Driver.find_element_by_xpath(xpath_value)
        self.Driver.implicitly_wait(10)
        randMail.click()
        time.sleep(1)
    def getVale_f_xpath(self,xpath_value,types = 'text'):
        ValueEle = self.Driver.find_element_by_xpath(xpath_value)
        if types == 'text':
            return ValueEle.text
        else:
            return ValueEle.get_attribute(types)
    def getEmail(self):
        all_handles = self.Driver.window_handles
        self.Driver.switch_to_window(all_handles[0])
    def openUrlInNewPage(self, url):
        js='window.open("{url}");'.format(url=url)
        self.Driver.implicitly_wait(10)
        self.Driver.execute_script(js)
        all_handles = self.Driver.window_handles
        self.Driver.switch_to_window(all_handles[-1])
        
        
    def close_other_windows(self):
        all_handles = self.Driver.window_handles
        if len(all_handles)>1:
            for i in range(1,len(all_handles)):
                self.Driver.switch_to_window(all_handles[i])
                self.Driver.close()
                self.Driver.switch_to_window(all_handles[0])
        self.Driver.refresh()
#        all_handles = Driver.window_handles
    def send_keys(self,xpath_value,value):
        input_ele = self.Driver.find_element_by_xpath(xpath_value)
        input_ele.clear()
        input_ele.send_keys(value)

    def crop_img(self,xpath_value):
        self.Driver.get_screenshot_as_file('screenshot.png')
        element = self.Driver.find_element_by_xpath("//img[@id='register_codeImage']")
        left = int(element.location['x'])
        top = int(element.location['y'])
        right = int(element.location['x'] + element.size['width'])
        bottom = int(element.location['y'] + element.size['height'])
        im = Image.open('screenshot.png')
        im = im.crop((left, top, right, bottom))
        im.save('code.png')
        return im
    def pretreat_image(self,image):
        # 将图片转换成灰度图片
        image = image.convert("L")
    
        # 二值化,得到0/255二值图片
        # 阀值threshold = 180
        image = self.iamge2imbw(image,100)
        
        # 对二值图片进行降噪
        # N = 4
        self.clear_noise(image,3)
    
        # 去除外边框
        # 原图大小:122*54
        # 左上右下,左 <= x < 右
        #box = (   8,   10,  118,  50 )
        #image = image.crop(box)
        return image
    def iamge2imbw(self,image,threshold):
        # 设置二值化阀值
        table = []
        for i in range(256):
            if i < threshold:
                table.append(0)
            else:
                table.append(1)
    
        # 像素值变为0,1
        image = image.point(table,'1')
    
        # 像素值变为0,255
        image = image.convert('L')
        return image
    # 根据一个点A的灰度值(0/255值),与周围的8个点的值比较
# 降噪率N: N=1,2,3,4,5,6,7
# 当A的值与周围8个点的相等数小于N时,此点为噪点
# 如果确认是噪声,用该点的上面一个点的值进行替换
    def get_near_pixel(self,image,x,y,N):
        pix = image.getpixel((x,y))
    
        near_dots = 0
        if pix == image.getpixel((x - 1,y - 1)):
            near_dots += 1
        if pix == image.getpixel((x - 1,y)):
            near_dots += 1
        if pix == image.getpixel((x - 1,y + 1)):
            near_dots += 1
        if pix == image.getpixel((x,y - 1)):
            near_dots += 1
        if pix == image.getpixel((x,y + 1)):
            near_dots += 1
        if pix == image.getpixel((x + 1,y - 1)):
            near_dots += 1
        if pix == image.getpixel((x + 1,y)):
            near_dots += 1
        if pix == image.getpixel((x + 1,y + 1)):
            near_dots += 1
    
        if near_dots < N:
            # 确定是噪声,用上面一个点的值代替
            return image.getpixel((x,y-1))
        else:
            return None

    # 降噪处理
    def clear_noise(self,image,N):
        draw = ImageDraw.Draw(image)
    
        # 外面一圈变白色
        Width,Height=image.size
        for x in range(Width):
            draw.point((x,0),255)
            draw.point((x,Height-1),255)
        for y in range(Height):
            draw.point((0,y),255)
            draw.point((Width-1,y),255)
    
        # 内部降噪
        for x in range(1,Width - 1):
            for y in range(1,Height - 1):
                color = self.get_near_pixel(image,x,y,N)
                if color != None:
                    draw.point((x,y),color)
    def getvcode(self,xpath_value,try_value):
        while True:
            im = self.crop_img(xpath_value)
            image = self.pretreat_image(im)
            vcode = pytesseract.image_to_string(image,config='-psm 7').replace(" ","")
            print(vcode)
            if re.match('[A-Za-z0-9]{4}',vcode) and len(vcode) == 4:
                return vcode
            else:
                self.click_xpath(try_value)
    def get_image(self,div):
#        print("#找到图片所在的div")
        headers = {"User-Agent":str(generate_user_agent())}
        background_images=self.Driver.find_elements_by_xpath(div)
        location_list=[]
        imageurl=''
        #图片是被CSS按照位移的方式打乱的,我们需要找出这些位移,为后续还原做好准备
        for background_image in background_images:
#            print(background_image.get_attribute('style'))
            location={}
            #在html里面解析出小图片的url地址，还有长高的数值
            location['x']=int(re.findall("background-image: url\(\"?(.*?)\"?\); background-position: \"?(.*?)\"?px \"?(.*?)\"?px;",background_image.get_attribute('style'))[0][1])
            location['y']=int(re.findall("background-image: url\(\"?(.*?)\"?\); background-position: \"?(.*?)\"?px \"?(.*?)\"?px;",background_image.get_attribute('style'))[0][2])
            imageurl=re.findall("background-image: url\(\"?(.*?)\"?\); background-position: \"?(.*)\"?px \"?(.*?)\"?px;",background_image.get_attribute('style'))[0][0]
            location_list.append(location)
        #替换图片的后缀,获得图片的URL
        imageurl=imageurl.replace("webp","jpg")
        #获得图片的名字
        imageName = imageurl.split('/')[-1]
        #获得图片
        s = requests
        r = s.get(imageurl, headers = headers)
#        with open(imageName,'wb') as f:
#            f.write(r.content)
        imageName = BytesIO(r.content)
        #重新合并还原图片
        image=self.get_merge_image(imageName, location_list)
        return image
    
    def get_merge_image(self,imageName,location_list):
        #打开图片文件
        im = Image.open(imageName)
        #创建新的图片,大小为260*116
        new_im = Image.new('RGB', (260,116))
        im_list_upper=[]
        im_list_down=[]
        # 拷贝图片
        for location in location_list:
            #上面的图片
            if location['y']==-58:
                im_list_upper.append(im.crop((abs(location['x']),58,abs(location['x'])+10,166)))
            #下面的图片
            if location['y']==0:
                im_list_down.append(im.crop((abs(location['x']),0,abs(location['x'])+10,58)))
        new_im = Image.new('RGB', (260,116))
        x_offset = 0
        #黏贴图片
        for im in im_list_upper:
            new_im.paste(im, (x_offset,0))
            x_offset += im.size[0]
        x_offset = 0
        for im in im_list_down:
            new_im.paste(im, (x_offset,58))
            x_offset += im.size[0]
#        os.remove(imageName)
        return new_im
        
        
    def get_track(self,length):
        pass
        list=[]
        #间隔通过随机范围函数来获得,每次移动一步或者两步
        x=random.randint(1,3)
        #生成轨迹并保存到list内
        while length-x>=5:
            list.append(x)
            length=length-x
            x=random.randint(1,3)
        #最后五步都是一步步移动
        for i in range(length):
            list.append(1)
        return list
    
    
    def get_diff_location(self,image1,image2):
        i=0
        # 两张原始图的大小都是相同的260*116
        # 那就通过两个for循环依次对比每个像素点的RGB值
        # 如果相差超过50则就认为找到了缺口的位置
        for i in range(0,260):
            for j in range(0,116):
                if self.is_similar(image1,image2,i,j)==False:
                    return  i
    
    def is_similar(self,image1,image2,x,y):
        pass
        #获取指定位置的RGB值
        pixel1=image1.getpixel((x,y))
        pixel2=image2.getpixel((x,y))
        for i in range(0,3):
            # 如果相差超过50则就认为找到了缺口的位置
            if abs(pixel1[i]-pixel2[i])>=50:
                return False
        return True
    
    def main(self):
        time.sleep(2)
        #等待页面的上元素刷新出来
        WebDriverWait(self.Driver, 30).until(lambda the_driver: the_driver.find_element_by_xpath("//div[@class='gt_slider_knob gt_show']").is_displayed())
        WebDriverWait(self.Driver, 30).until(lambda the_driver: the_driver.find_element_by_xpath("//div[@class='gt_cut_bg gt_show']").is_displayed())
        WebDriverWait(self.Driver, 30).until(lambda the_driver: the_driver.find_element_by_xpath("//div[@class='gt_cut_fullbg gt_show']").is_displayed())
        image1=self.get_image("//div[@class='gt_cut_bg gt_show']/div")#需要拼接的图
        image2=self.get_image("//div[@class='gt_cut_fullbg gt_show']/div")#复原图
        loc=self.get_diff_location(image1, image2)
        #生成x的移动轨迹点
        track_list=self.get_track(loc)
        #找到滑动的圆球
        element=self.Driver.find_element_by_xpath("//div[@class='gt_slider_knob gt_show']")
        ActionChains(self.Driver).click_and_hold(on_element=element).perform()
        
        location=element.location
        #获得滑动圆球的高度
        y=location['y']
        ActionChains(self.Driver).move_to_element_with_offset(to_element=element, xoffset=50+22, yoffset=y-445).perform()
        ActionChains(self.Driver).move_to_element_with_offset(to_element=element, xoffset=22-50, yoffset=y-445).perform()
        #鼠标点击元素并按住不放
        
#        print ("第一步,点击元素")
        
        #ActionChains(driver).click_and_hold(on_element=element).perform()
        time.sleep(1)
#        print ("第二步，拖动元素")
        #track_string = ""
#        print(track_list)
#        print(len(track_list))
#        t=random.random()+1
#        print(t)
        #m=0
        along = sum(track_list)
        Now = time.time()-5
        long = 0
        while long<along:#3步位移
            a = random.randint(0,20)
#            print(a)
            if long+a<along:
                pass
            else:
                a = along-long
            ActionChains(self.Driver).move_to_element_with_offset(to_element=element, xoffset=a+22, yoffset=y-445).perform()
            long+=a
            time.sleep(0.1/((time.time()-Now+random.random())**2))
            
        ActionChains(self.Driver).move_to_element_with_offset(to_element=element, xoffset=22-5, yoffset=y-445).perform()
#        print ("第三步，释放鼠标")
        #释放鼠标
        time.sleep(0.1)
        ActionChains(self.Driver).release(on_element=element).perform()
        time.sleep(1)
        response = self.Driver.page_source.encode('utf-8').decode("utf-8")
    #    print(response)
        self.Driver.get_screenshot_as_file('screenshot1.png')
        return response
    """
    激活emali
    """
    def activation(self,email):
        try:
            Email = email
            all_handles = self.Driver.window_handles
            self.Driver.switch_to_window(all_handles[0])
            fid = self.Driver.find_element_by_xpath("//input[@name='delMail']")
            fid = fid.get_property("value")
            Email = Email.replace("@","(a)").replace("www.","www-_-")
            url = "http://www.bccto.me/win/{Email}/{fid}".format(Email=Email,fid=fid)
            js = 'window.open("{url}");'.format(url=url)
            self.Driver.implicitly_wait(10)
            self.Driver.execute_script(js)
            time.sleep(1)
            all_handles = self.Driver.window_handles
            self.Driver.switch_to_window(all_handles[2])
#            html = self.Driver.page_source.encode('utf-8').decode("utf-8")
#            print(html)
            url_ = self.Driver.find_element_by_xpath('/html/body/div/div[2]/a')
            url_ = url_.get_property("href")
            print(url_)
            js = 'window.open("{url}");'.format(url=url_)
            self.Driver.implicitly_wait(10)
            requests.get(url_)
            time.sleep(3)
            with open("f://account.txt","a") as f:
                f.write(email+"\n")
                print(Email)
        except:
            pass
    def closeDriver(self):
        self.Driver.quit()
    """
    tyr again
    """
if __name__ == '__main__':
    a = pedata_register()
    a.openDriver('http://www.bccto.me/','//div[@id="cnt_0"]')
    n = 0
    while n < 50:
        while True:
            flag=False
            a.close_other_windows()
            a.openDriver('http://www.bccto.me/','//div[@id="cnt_0"]')
            a.click_xpath('//button[@id="randMail"]')
            a.click_xpath('//button[@id="applyMail"]')
            time.sleep(3)
            Email = a.getVale_f_xpath("//span[@id='showmail']",)
            print(Email)
            a.openUrlInNewPage("http://www.pedata.cn/auth_do/m_toregister")
            a.send_keys('//input[@name="email"]',Email)
            a.send_keys('//input[@name="password"]',"111111")
            a.send_keys('//input[@name="pwd"]',"111111")
            trytimes = 1
            if trytimes!=1:
                a.click_xpath("//img[@id='register_codeImage']")
            else:
                pass
            trytimes+=1
            im = a.crop_img("//img[@id='register_codeImage']")
            vcode = a.getvcode("//img[@id='register_codeImage']","//img[@id='register_codeImage']")
            a.send_keys('//input[@id="codeImageValue"]',vcode)
            a.click_xpath("//input[@value='注 册']")
            response = a.main()
            if response.count(Email)>1:
                print("sucess %s"%Email)
                time.sleep(3)
                a.activation(Email)
                n+=1
                break
            else:
                pass
    a.closeDriver()
            